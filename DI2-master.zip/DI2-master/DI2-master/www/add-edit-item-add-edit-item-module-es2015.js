(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-edit-item-add-edit-item-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/add-edit-item/add-edit-item.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/add-edit-item/add-edit-item.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>TUTORIAL DE TAREAS</ion-title>\n    <ion-buttons slot=\"primary\">\n        <ion-button color=\"danger\" [routerLink]=\"['/home']\"><ion-icon slot=\"icon-only\" name=\"close\"></ion-icon></ion-button>\n        <ion-button color=\"primary\" (click)=\"save()\"><ion-icon slot=\"icon-only\" name=\"checkmark\"></ion-icon></ion-button>\n    </ion-buttons>       \n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-list>\n    <ion-item>\n      <ion-label position=\"floating\">Selecciona la fecha</ion-label>\n      <ion-datetime display-format=\"D MMM YYYY\" max=\"2050-12-31\" [(ngModel)]=\"item.date\"></ion-datetime>      \n    </ion-item>\n    <ion-item>\n      <ion-label position=\"floating\">Meteme una tarea</ion-label>\n      <ion-input [(ngModel)]=\"item.task\"></ion-input>\n    </ion-item>\n  </ion-list>\n  <ion-segment [(ngModel)]=\"item.icon\">\n    <ion-segment-button *ngFor=\"let button of buttons\" [value]=\"button\">\n      <ion-icon [name]=\"button\"></ion-icon>\n    </ion-segment-button>\n  </ion-segment>\n</ion-content>");

/***/ }),

/***/ "./src/app/add-edit-item/add-edit-item-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/add-edit-item/add-edit-item-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: AddEditItemPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddEditItemPageRoutingModule", function() { return AddEditItemPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _add_edit_item_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./add-edit-item.page */ "./src/app/add-edit-item/add-edit-item.page.ts");




const routes = [
    {
        path: '',
        component: _add_edit_item_page__WEBPACK_IMPORTED_MODULE_3__["AddEditItemPage"]
    }
];
let AddEditItemPageRoutingModule = class AddEditItemPageRoutingModule {
};
AddEditItemPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AddEditItemPageRoutingModule);



/***/ }),

/***/ "./src/app/add-edit-item/add-edit-item.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/add-edit-item/add-edit-item.module.ts ***!
  \*******************************************************/
/*! exports provided: AddEditItemPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddEditItemPageModule", function() { return AddEditItemPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _add_edit_item_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./add-edit-item-routing.module */ "./src/app/add-edit-item/add-edit-item-routing.module.ts");
/* harmony import */ var _add_edit_item_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-edit-item.page */ "./src/app/add-edit-item/add-edit-item.page.ts");







let AddEditItemPageModule = class AddEditItemPageModule {
};
AddEditItemPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _add_edit_item_routing_module__WEBPACK_IMPORTED_MODULE_5__["AddEditItemPageRoutingModule"]
        ],
        declarations: [_add_edit_item_page__WEBPACK_IMPORTED_MODULE_6__["AddEditItemPage"]]
    })
], AddEditItemPageModule);



/***/ }),

/***/ "./src/app/add-edit-item/add-edit-item.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/add-edit-item/add-edit-item.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FkZC1lZGl0LWl0ZW0vYWRkLWVkaXQtaXRlbS5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/add-edit-item/add-edit-item.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/add-edit-item/add-edit-item.page.ts ***!
  \*****************************************************/
/*! exports provided: AddEditItemPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddEditItemPage", function() { return AddEditItemPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _list_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../list.service */ "./src/app/list.service.ts");





let AddEditItemPage = class AddEditItemPage {
    constructor(router, route, alertController, ListService) {
        this.router = router;
        this.route = route;
        this.alertController = alertController;
        this.ListService = ListService;
        this.buttons = ["radio-button-off", "radio-button-on", "snow", "flame"];
        this.tabIndex = +this.route.snapshot.paramMap.get('tab');
        this.itemIndex = +this.route.snapshot.paramMap.get('item');
        if (this.itemIndex >= 0) {
            this.item = Object.assign({}, this.ListService.getItem(this.tabIndex, this.itemIndex));
            this.item.date = new Date(this.item.date).toISOString();
        }
        else {
            this.item = { date: new Date().toISOString(), task: '', icon: 'radio-button-off' };
        }
    }
    error(message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: message,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    save() {
        if (!this.item.task.length) {
            this.error('The task cannot be empty');
        }
        else {
            if (this.itemIndex >= 0) {
                this.ListService.setItem(this.tabIndex, this.item, this.itemIndex);
            }
            else {
                this.ListService.setItem(this.tabIndex, this.item);
            }
            this.router.navigate(['/home']);
        }
    }
};
AddEditItemPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _list_service__WEBPACK_IMPORTED_MODULE_4__["ListService"] }
];
AddEditItemPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-add-edit-item',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./add-edit-item.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/add-edit-item/add-edit-item.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./add-edit-item.page.scss */ "./src/app/add-edit-item/add-edit-item.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
        _list_service__WEBPACK_IMPORTED_MODULE_4__["ListService"]])
], AddEditItemPage);



/***/ })

}]);
//# sourceMappingURL=add-edit-item-add-edit-item-module-es2015.js.map